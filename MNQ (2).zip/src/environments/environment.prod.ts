export const environment = {
  production: true,
  baseURL: 'https://cyber-project-master.herokuapp.com',
  fileSize: 1048576,
  fileAllowedExt: "['.jpg', '.jpeg', '.JPG', '.JPEG', '.png', '.PNG', '.pdf']"
};
